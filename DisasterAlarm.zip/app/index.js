/*
 * Entry point for the watch app
 */
import document from "document";
import { geolocation } from "geolocation";
import { vibration } from "haptics";
import { BodyPresenceSensor } from "body-presence";
import { HeartRateSensor } from "heart-rate";
import { settingsStorage } from "settings";

function hb(){
  if (BodyPresenceSensor) {
    const body = new BodyPresenceSensor();
    const hrm = new HeartRateSensor({ frequency: 1 });
    if (HeartRateSensor){
      body.addEventListener("reading", () => {
        if (!body.present) {
          hrm.stop();
        } else {
          hrm.start();
          let a =  `${hrm.heartRate}`;
          console.log(`Current heart rate: `+a);
          document.getElementById("heartRate").text = a;
          a = parseInt(a);
          if(a<40){
            vibration.start("ring");
          }
        }
      });
    }
    body.start();
  }
}  
var k = setInterval(hb,10000);

// check kind of Disaster
// change demotext.text
let disasterkind = document.getElementById("disasterkind");
var disasterName = disasterkind.text; // GET DISASTER NAME


// GET DISASTER STATUS --> CHANGE BACKGROUND COLOR
// GREEN YELLOW RED
var disasterStatus = "YELLOW";

var main = document.getElementById("main_dis");
if(disasterStatus == "YELLOW"){
  main.style.fill = "orangered";
}
if(disasterStatus == "RED"){
  main.style.fill = "fb-red";
}

function disasterManual(disaster){
  if(disaster == "Earthquake"){
    let content = new Array(8);
    for(var i=1;i<9;i++){
      let item = "item"+i;
      content[i-1] = document.getElementById(item).getElementsByTagName("textarea")[0];
    }
    content[0].text = "Secure Your Space by identifying hazards and securing moveable items";
    content[1].text = "Plan to Be Safe by creating a disaster plan and deciding how you will communicate in an emergency";
    content[2].text = "Organize Disaster Supplies in convenient locations";
    content[3].text = "Minimize Financial Hardship by organizing important documents, strengthening your property, and considering insurance";
    content[4].text = "Drop, Cover, and Hold On when the ground shakes";
    content[5].text = "Improve Safety after earthquakes by evacuating if necessary, helping the injured, and preventing further injuries or damage.";
    content[6].text = "Reconnect and Restore: Restore daily life by reconnecting with others, repairing damage, and rebuilding community";
    content[7].text = "END";
  }
  if(disaster == "Flood"){
    let content = new Array(10);
    for(var i=1;i<11;i++){
      let item = "item"+i;
      content[i-1] = document.getElementById(item).getElementsByTagName("textarea")[0];
    }
    content[0].text = "Keep important documents in a waterproof container. Create password-protected digital copies.";
    content[1].text = "Depending on where you are, and the impact and the warning time of flooding, go to the safe location that you previously identified.";
    content[2].text = "Do not walk, swim, or drive through flood waters.";
    content[3].text = "Stay off bridges over fast-moving water. Fast-moving water can wash bridges away without warning.";
    content[4].text = "If your vehicle is trapped in rapidly moving water, then stay inside. If water is rising inside the vehicle, then seek refuge on the roof.";
    content[5].text = "Go to highest level. Do not climb into a closed attic. Go on the roof only if necessary. Once there, signal for help.";
    content[6].text = "Listen to authorities for information and instructions. Return home only when authorities say it is safe.";
    content[7].text = "Avoid driving, except in emergencies."
    content[8].text = "Be aware of the risk of electrocution. Do not touch electrical equipment. Touch only afater turning off the electricity to prevent electric shock.";
    content[9].text = "END";
    
    }
  if(disaster == "Fire"){
    let content = new Array(9);
    for(var i=1;i<10;i++){
      let item = "item"+i;
      content[i-1] = document.getElementById(item).getElementsByTagName("textarea")[0];
    }
    content[0].text = "Identify fire hazards: ignition / fuel / oxygen";
    content[1].text = "Identify people at risk: People in and around the premises / People especially at risk";
    content[2].text = "Press the fire alarm emergency bell";
    content[3].text = "Use the stairs instead of the elevator, but if you can't evacuate downstairs, evacuate to the roof";
    content[4].text = "Cover your body and face with a wet blanket or wet towel when passing through the flames";
    content[5].text = "If there is a lot of smoke, cover your nose and mouth with a wet towel with one hand and move to a lower position";
    content[6].text = "If you do not feel hot when you touch the door handle before opening the door, open the door carefully and go out";
    content[7].text = "If there is no exit, wet the door to prevent smoke from entering the room, cover the door with clothes or a blanket and wait for rescue";
    content[8].text = "END";
  }
  if(disaster == "Volcano"){
    let content = new Array(9);
    for(var i=1;i<10;i++){
      let item = "item"+i;
      content[i-1] = document.getElementById(item).getElementsByTagName("textarea")[0];
    }
    content[0].text = "Before Ash Fallen: Block doors and windows with tapes and water-soaked towels";
    content[1].text = "Before Ash Fallen: To seperate the drain or drain pipe from the roof gutter to prevent the drain from being blocked";
    content[2].text = "Before Ash Fallen: When using a rainwater collection facility for water supply, seperate the rainwater collection facility and the pipe connected to the tank";
    content[3].text = "Falling Ash: Avoid unnecessary outdoors";
    content[4].text = "Falling Ash: If you are outdoors, evacuate quickly to car or building";
    content[5].text = "Cover your nose and mouth with a mask or clothing";
    content[6].text = "Listen to disaster broadcasts about volcanic ash";
    content[7].text = "Do not wear contact lenses, and if volcanic ash enters to the water, use it after sinking";
    content[8].text = "END";
  }
  if(disaster == "Collapse"){
    let content = new Array(7);
    for(var i=1;i<8;i++){
      let item = "item"+i;
      content[i-1] = document.getElementById(item).getElementsByTagName("text");
    }
    content[0].text = "If your building collapses, don't panic and look around to find an escape route.";
    content[1].text = "When you get out of the building, evacuate to a safe area where there is no danger of additional collapse or explosion.";
    content[2].text = "Temporarily evacuate to a safe place with strong walls, such as an elevator hall or staircase.";
    content[3].text = "Residents outside the collapsed building are at risk of further collapse, gas explosions and fires, do not approach the scene of the accident to avoid damage.";
    content[4].text = "When walking or moving around the collapsed area, keep your head away from dangerous areas or unstable objects and protect your head with bags, cushions, books, etc. to avoid injury from glass fragments.";
    content[5].text = "The injured person should go to a safe place as soon as possible and provide first aid.";
    content[6].text = "END";
  }   
}



// default

let mainPage = document.getElementById("main_dis");
          

let manualPageButton = document.getElementById("manualButton");
let manualPage = document.getElementById("manual_dis");
manualPageButton.onclick = function (){
  mainPage.style.display = (mainPage.style.display === "inline") ? "none" : "inline";
  disasterManual(disasterName);
  manualPage.style.display = (manualPage.style.display === "inline") ? "none" : "inline";

}


let backstageButtonmn = document.getElementById("btn-brmn");


backstageButtonmn.onclick = function(){
  mainPage.style.display = (mainPage.style.display === "inline") ? "none" : "inline";
  this.parent.style.display = (this.parent.style.display === "inline") ? "none" : "inline";
}



//if emergencyCall button clicked --> ring
let emergencyCallButton = document.getElementById("emergencyCallButton");
emergencyCallButton.onclick=function(){
  vibration.start("ring");
}

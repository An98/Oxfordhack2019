import * as messaging from "messaging";
import { BodyPresenceSensor } from "body-presence";
import { geolocation } from "geolocation";
import { HeartRateSensor } from "heart-rate";
import { me } from "companion";
import { outbox } from 'file-transfer';
import { encode } from 'cbor';
import { settingsStorage } from "settings";


console.log("Companion start");
let lat,lon;
geolocation.getCurrentPosition(locationSuccess, locationError);

function locationSuccess(position) {
  lat = position.coords.latitude;
  lon = position.coords.longitude;
  
}

function locationError(error) {
  console.log("Error: " + error.code,
              "Message: " + error.message);
}

var url = 'https://nodeprojectoxford.azurewebsites.net/';

if (!me.permissions.granted("access_internet")) {
  console.log("We're not allowed to access the internet!");
}
console.log("Companion starting! LaunchReasons: " + JSON.stringify(me.launchReasons));


function fetchgps(){
  console.log("fetch start")
 if(messaging.peerSocket.readyState === messaging.peerSocket.OPEN)
    fetch(url+"latitude="+lat+"longitude="+lon, {
    method: 'get',
    body:""
  })
 .then(response => response.json())
.then(data => {
  console.log(data) // Prints result from `response.json()` in getRequest
      document.getElementById("disasterkind").innerHTML=data;
})
.catch(error => console.log(error))

  }
function process(data){
  console.log(data.type);
  
}
messaging.peerSocket.onopen=function(){
  fetchgps();
}
messaging.peerSocket.onmessage = function(evt){
  if(evt.data){
    process(evt.data);
  }
}

messaging.peerSocket.onerror = function(err){
  console.log("Connection error");
}


var connectionInterval = setInterval(function() {
  if(messaging.peerSocket.readyState == messaging.peerSocket.OPEN){
    clearInterval(connectionInterval);
    console.log("Companion: Connected");
  }
}, 3000);

var url2 = https:\/\/nodeprojectoxford.azurewebsites.net/call;

function fetchget(){

  console.log("fetch start")
 if(messaging.peerSocket.readyState === messaging.peerSocket.OPEN)
    fetch(url, {
    method: 'get',
    body:""
  })
 .then(response => response.json())
.then(data => {
  console.log(data) // Prints result from `response.json()` in getRequest
      document.getElementById("disasterkind").innerHTML=data;
})
.catch(error => console.log(error))

  
}

messaging.peerSocket.onopen=function(){
  fetchget();
}
messaging.peerSocket.onmessage = function(evt){
  if(evt.data){
    process(evt.data);
  }
}
